  id="{b306f916-a4a1-4426-91a7-060ce76131d2}"
  version="1.0.0.1 
  title="EllipseViewAngle" 